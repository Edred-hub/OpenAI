Contents for sample custom GPT (jokemaster)  
