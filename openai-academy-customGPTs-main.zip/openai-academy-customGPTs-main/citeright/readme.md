Contents for Citeright custom GPT
