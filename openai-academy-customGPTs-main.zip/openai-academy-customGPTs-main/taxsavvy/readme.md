Assets for Taxsavvy custom gpt
