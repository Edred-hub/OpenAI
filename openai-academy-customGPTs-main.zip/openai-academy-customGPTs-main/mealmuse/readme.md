Contents for the Mealmuse custom GPT
